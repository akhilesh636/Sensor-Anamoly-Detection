/*
 * dht22.h
 *
 *  Created on: Feb 13, 2024
 *      Author: akhilesh
 */

#ifndef INC_DHT22_H_
#define INC_DHT22_H_

#include "stm32f4xx_hal.h"

void DHT22_Start (void);

uint8_t DHT22_Check_Response (void);

uint8_t DHT22_Read (void);

#endif /* INC_DHT22_H_ */
